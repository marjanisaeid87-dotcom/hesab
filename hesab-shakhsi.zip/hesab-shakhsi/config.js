// ================================================================
//  تنظیمات اتصال به Supabase
//  این دو مقدار را از Supabase → Project Settings → API (یا Data API) کپی کنید.
//  کلید anon / publishable عمومی است و قرار گرفتنش در سایت مشکلی ندارد؛
//  امنیت داده‌ها با ورود (رمز عبور) و Row Level Security تأمین می‌شود.
//  ⚠️ هرگز کلید service_role یا secret را اینجا نگذارید.
// ================================================================
window.APP_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-OR-PUBLISHABLE-KEY",
};
